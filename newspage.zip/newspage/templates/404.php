<div class="container">
	<div class="row">
		<h1 class="text-danger">OOPS! Trang này không tồn tại</h1>
		<a href="<?php echo $_DOMAIN; ?>">Trở về trang chủ</a>
	</div>
</div>